sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("invoiceapproval_S4Hana.controller.DetailObjectNotFound", {});
});
